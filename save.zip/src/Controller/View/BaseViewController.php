<?php

namespace App\Controller\View;

use App\Controller\BaseController;

abstract class BaseViewController extends BaseController
{
}
