<?php

namespace App\Controller\Api;

use App\Controller\Api\BaseApiController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/api/login')]
class ApiLoginController extends BaseApiController
{
    #[Route('/facebook', name: 'login_facebook')]
    public function loginWithFacebook(): Response
    {
        return $this->render('comment/index.html.twig', [
        ]);
    }
}
