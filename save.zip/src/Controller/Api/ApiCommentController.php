<?php

namespace App\Controller\Api;

use App\Controller\Api\BaseApiController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/api/comment')]
class ApiCommentController extends BaseApiController
{
    #[Route('/{id}', name: 'get_comment')]
    public function index(): Response
    {
        return $this->render('comment/index.html.twig', [
        ]);
    }
}
