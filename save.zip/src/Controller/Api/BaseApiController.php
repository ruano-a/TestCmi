<?php

namespace App\Controller\Api;

use App\Controller\BaseController;

abstract class BaseApiController extends BaseController
{
}
