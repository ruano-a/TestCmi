<?php

namespace App\Service;

class ArticleService
{
}
