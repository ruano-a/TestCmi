<?php

namespace App\Entity;

use App\Repository\ArticleRepository;
use App\Entity\Traits\Active;
use App\Entity\Traits\CreatedByUser;
use App\Entity\Traits\CreationDate;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

#[ORM\Entity(repositoryClass: ArticleRepository::class)]
class Article
{
    use Active;
    use CreatedByUser;
    use CreationDate;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    #[Groups(['read'])]
    #[Assert\Length(min: 5, minMessage: "title.length.min", max: 255, maxMessage: "title.length.max")]
    private ?string $title = null;

    #[ORM\Column(length: 4095)]
    #[Groups(['read'])]
    #[Assert\Length(min: 5, minMessage: "content.length.min", max: 4095, maxMessage: "content.length.max")]
    private ?string $content = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): self
    {
        $this->title = $title;

        return $this;
    }

    public function getContent(): ?string
    {
        return $this->content;
    }

    public function setContent(string $content): self
    {
        $this->content = $content;

        return $this;
    }
}
