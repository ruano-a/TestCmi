
import './styles/login.css';

console.log('hello');
function statusChangeCallback(response) {
    console.log('check login state');
    console.log(response);
}

window.fbAsyncInit = function() {
  FB.init({
    appId      : '916840026018060',
    cookie     : true,
    xfbml      : true,
    version    : 'v16.0'
  });

  FB.AppEvents.logPageView();   

};

function checkLoginState() {
  FB.getLoginStatus(function(response) {
    statusChangeCallback(response);
  });
}
window.checkLoginState = checkLoginState;

(function(d, s, id){
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) {return;}
 js = d.createElement(s); js.id = id;
 js.src = "https://connect.facebook.net/en_US/sdk.js";
 fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

FB.getLoginStatus(function(response) {
    statusChangeCallback(response);
});
var finished_rendering = function() {
  console.log("finished rendering plugins");
  var spinner = document.getElementById("spinner");
  spinner.removeAttribute("style");
  spinner.removeChild(spinner.childNodes[0]);
}
FB.Event.subscribe('xfbml.render', finished_rendering);